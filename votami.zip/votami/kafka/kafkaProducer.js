import { Kafka } from 'kafkajs'

const kafka = new Kafka({
  clientId: 'frontend-app',
  brokers: ['localhost:9092']
})

const producer = kafka.producer()

export async function produceMessageToKafka(topic, message) {
  await producer.connect()
  await producer.send({
    topic,
    messages: [{ value: JSON.stringify(message) }]
  })
  await producer.disconnect()
}