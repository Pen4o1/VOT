import { Kafka } from 'kafkajs'

const kafka = new Kafka({
  clientId: 'backend-app',
  brokers: ['localhost:9092']
})

const consumer = kafka.consumer({ groupId: 'backend-group' })

export async function subscribeToKafka() {
  await consumer.connect()
  await consumer.subscribe({ topic: 'tasks-topic', fromBeginning: true })

  await consumer.run({
    eachMessage: ({ topic, partition, message }) => {
      console.log({
        topic: topic,
        partition,
        offset: message.offset,
        value: message.value.toString()
      })
    }
  })
}