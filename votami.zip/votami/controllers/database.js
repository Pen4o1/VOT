import mysql from "mysql2";

export const database = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "changeme",
    database: "Votami",
}).promise()
