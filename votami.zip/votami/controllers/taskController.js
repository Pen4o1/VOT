import { database } from "./database.js";
import {produceMessageToKafka} from "../kafka/kafkaProducer.js";

export async function getTasks() {
    const [result] = await database.query("SELECT * FROM Tasks")
    return result
}

export async function getTaskByID(id) {
    const [result] = await database.query("SELECT * FROM Tasks WHERE id = ?", [id])
    return result[0]
}

export async function createTask(name, description) {
    const result = await database.query("INSERT INTO Tasks (name, description) VALUES (?, ?)", [name, description])
    
    const createdTask = {"id": result.insertId, "name": name, "description": description, "type": "Create"}
    await produceMessageToKafka("tasks-topic", createdTask)

    return result
}

export async function updateTask(id, name, description) {
    const result = await database.query("UPDATE Tasks SET name = ?, description = ? WHERE id = ?", [name, description, id])

    const updatedTask = {"id": id, "name": name, "description": description, "type": "Update"}
    await produceMessageToKafka("tasks-topic", updatedTask)

    return result
}

export async function deleteTaskByID(id) {
    const result = await database.query("DELETE FROM Tasks WHERE id = ?", [id])

    const deletedTask = {"id": id, "type": "Delete"}
    await produceMessageToKafka("tasks-topic", deletedTask)

    return result
}