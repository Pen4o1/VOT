import express from "express";
import cors from "cors";
import router from "./routers/router.js";
import { subscribeToKafka } from "./kafka/kafkaConsumer.js";

const app = express();
const port = 8080;

await subscribeToKafka();
app.use(cors());
app.use(express.json());
app.use("/tasks", router);

app.listen(port, () => {
    console.log(`App running on port ${port}.`);
});