import express from "express"
import { getTasks, getTaskByID, createTask, updateTask, deleteTaskByID } from "../controllers/taskController.js"
const router = express.Router()

router.get("/", async (req, res) => {
    const tasks = await getTasks();
    res.status(200).send(tasks);
})

router.get("/id/:id", async (req, res) => {
    const id = req.params.id
    const task = await getTaskByID(id);

    if(!task) {
        return res.status(404).send({message: "Invalid id"});
    }

    res.status(200).send(task);
})

router.post("/", async (req, res) => {
    const {name, description} = req.body;
    const task = await createTask(name, description);

    if(!task) {
        return res.status(400).send({message: "Cannot create task"});
    }

    res.status(200).send(task);
})

router.put("/id/:id", async (req, res) => {
    const id = req.params.id;
    const {name, description} = req.body;

    if(!await getTaskByID(id)) {
        return res.status(404).send({message: "Cannot find task"});
    }

    const result = await updateTask(id, name, description);
    res.status(200).send(result);
})

router.delete("/id/:id", async (req, res) => {
    const id = req.params.id;

    if(!await getTaskByID(id)) {
        return res.status(404).send({message: "Cannot find task"});
    }

    const result = await deleteTaskByID(id);
    res.status(200).send(result);
})

export default router;